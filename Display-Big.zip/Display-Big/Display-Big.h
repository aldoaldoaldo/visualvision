#ifndef Display-Big_h
#define Display-Big_h
#include <Arduino.h>

//
//VV 7 segment charset; bit0 sometimes is "point" (used apart)
//abc = ABC -> (the more readable letter is automatically shown)
//
const uint8_t d7charset[] PROGMEM = {
  0b00000000, /* (space) */
  0b00001100, /* ! */
  0b01000100, /* " */
  0b11111100, /* # */
  0b11011010, /* $ */
  0b10100100, /* % */
  0b10001100, /* & */
  0b01000000, /* ' */
  0b01110010, /* ( */ //  0b01010010, /* ( */
  0b00011110, /* ) */ //  0b00010110, /* ) */
  0b11000110, /* * */ //  0b01000010
  0b11100000, /* + */
  0b00100000, /* , */
  0b10000000, /* - */
  0b00000000, /* . */
  0b10100100, /* / */
  0b01111110, /* 0 */
  0b00001100, /* 1 */
  0b10110110, /* 2 */
  0b10011110, /* 3 */
  0b11001100, /* 4 */
  0b11011010, /* 5 */
  0b11111010, /* 6 */
  0b00001110, /* 7 */
  0b11111110, /* 8 */
  0b11011110, /* 9 */
  0b00010010, /* : */
  0b00011010, /* ; */
  0b11000010, /* < */
  0b10010000, /* = */
  0b10000110, /* > */
  0b10100110, /* ? */
  0b10111110, /* @ */
  0b11101110, /* A */
  0b11111000, /* B */
  0b01110010, /* C */
  0b10111100, /* D */
  0b11110010, /* E */
  0b11100010, /* F */
  0b01111010, /* G */
  0b11101000, /* h */ // 0b1110110, /* H */
  0b01100000, /* I */
  0b00111100, /* J */
  0b11101010, /* K */
  0b01110000, /* L */
  0b10101000, /* M */ // da 0b00101010
  0b01101110, /* N */
  0b01111110, /* O */
  0b11100110, /* P */
  0b11001110, /* q */ // 0b1101011, /* Q */
  0b10100000, /* r */ // 0b0110011, /* R */
  0b11011010, /* S */
  0b11110000, /* T */
  0b01111100, /* U */
  0b01111000, /* V v */
  0b00111000, /* W */ // 0b01010100
  0b11101100, /* X */
  0b11011100, /* Y */
  0b10110110, /* Z */
  0b01110010, /* [ */
  0b11001000, /* \ */
  0b00011110, /* ] */
  0b01000110, /* ^ */
  0b00010000, /* _ */
  0b11000110  /* ` */ // 0b00000100 replaced with �
};

//#define PHH 0b11111110
//#define PLL 0b11111111

#define PHH LOW
#define PLL HIGH


class DisplayBig
{
  public:    
    //
    //Create Object and inizializes.
    //size -> display size (e.g. 4 chars/letters)
    //si   -> GPIO for SI  (e.g. 12)
    //sck  -> GPIO for SCK (e.g. 14)
    //rck  -> GPIO for RCK (e.g. 13) (IF USED)
    //NOTE=>if you are not using RCK and the solderJumper RCK-SI is c.c., do not pass rck
    DisplayBig(uint8_t size,uint8_t si,uint8_t sck,uint8_t rck=255);
    //
    //set size as above; e.g. 4 for one 8888, 8 for 8888+8888, 6  for 88+88+88, etc...
    void setsize(uint8_t size);
    //
    //inits GPIO out used
    void GPIOinit();
    //
    //shows string dd (only first _size letters)
    //void show(const String &dd);
    void show(String);
    //shows string dd and if less than _size it replicates
    //example dd=" -" for 8888+8888 display is shown as " - - - -"
    //void showexp(const String &dd);
    void showexp(String);
    //adds the char c to the right, and scrolls left all the rest
    void scroll(char c);
    //clears the display
    void clear();
    //forces display refresh
    void refresh();
    //
    //set points accordingo to "punti" that contains bit by bit 1 for ON and 0 for OFF,
    //this for cascading displays, for max 16 points, like in this table:
    //
    //one 8888-display
    //           88.88
    //punti bit#   0
    //
    //two 88-display (cascading)
    //           88.88.
    //punti bit#   0  1
    //
    //two 8888-display (cascading)
    //           88.88 88.88
    //punti bit#   0     2
    //
    //3x  88-display
    //           88.88.88.
    //punti bit#   0  1  2
    //
    //4x  88-display
    //           88.88.88.88.
    //punti bit#   0  1  2  3
    //
    //3x 8888-display (cascading)
    //           88.88 88.88 88.88
    //punti bit#   0     2     4
    //
    //etc.etc.etc... (available bit/pt-> 0..31)
    //
    //if dorefresh=true forces display refresh (false by default because if you use .show() 
    // just after, .show() will do the refresh
    void setpoints(uint32_t punti,bool dorefresh=false);
    void pointOFF(uint32_t mask,bool dorefresh=false);
    void pointON(uint32_t mask,bool dorefresh=false);
    uint32_t getpoints();
    String getdisp();
        
  private:
    uint32_t _punti;
    uint8_t _size;
    uint8_t _si;
    uint8_t _sck;
    uint8_t _rck;
    String _disp="";
    bool _setting=false;

    char code7(char c);
    void cifra(char cf,uint8_t pt=PLL);
};

#endif