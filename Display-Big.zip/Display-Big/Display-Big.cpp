#include "./Display-Big.h"
#include <Arduino.h>


DisplayBig::DisplayBig(uint8_t size,uint8_t si,uint8_t sck,uint8_t rck)
//default _rck=255 -> RCK join SI (if rck not passed)
{
  _size = size;
  _si = si;
  _sck= sck;
  _rck= rck;
  _punti=0;
  _disp="";
}


void DisplayBig::GPIOinit()
{
  pinMode(_sck,OUTPUT);
  digitalWrite(_rck,HIGH);
  pinMode(_si,OUTPUT);
  digitalWrite(_si,HIGH);
  if (_rck<255) {
    pinMode(_rck,OUTPUT);
    digitalWrite(_rck,HIGH);
  }
}

void DisplayBig::clear()
{
  int i=_size;
  _disp="";
  String s="";
  while (i>0) { 
    s+=' ';
    i--;
  }
  show(s);
}

void DisplayBig::show(String dd)
//void DisplayBig::show(const String &dd)
{
  if (_disp!=dd) {
    _disp=dd;
    refresh();
  } 
}

void DisplayBig::showexp(String dd)
//void DisplayBig::showexp(const String &dd)
{
  int volte=_size/dd.length();
  if (volte>1) {
    String s=dd;
    while (volte>1) {
      s+=dd;
      volte--;
    }
    show(s);
  }
  else show(dd);
}

char DisplayBig::code7(char c) {
  if ((c<' ') || (c>'z')) c=' ';
  if (c>='a') c=c-('a'-'A');
  if (c=='�') c='a';
  else if ((c=='�') || (c=='�')) c='e';
  else if (c=='�') c='i';
  else if (c=='�') c='o';
  else if (c=='�') c='u';
  int i=c-32;
  return ~pgm_read_byte(d7charset+i);  // ~ dovrebbe essere il NOT
}

void DisplayBig::refresh()
{
  if (!_setting) //this avoids calling it when it is still executing the previous call
  {
    _setting=true;    
	String s=_disp;
	
	//s will be at least "_size" chars
	int i=_size-s.length();
    while (i>0) { 
      s+=' ';
      i--;
    }
    
    //sends data to registers
    i=0;
    int j,ii;
    uint8_t p=PLL;
    while (i<_size) 
    {
      j=i/2;
      ii=i%2;
      if (j+ii>32) { p=PLL; } //we memorize max 32 points in _punti
      else 
      if (ii==1) {
        //legacy; in some old boards the point is connected to the next register
        //so we "do" the point for 2 registers, "correct" and next
        if (bitRead(_punti,j)==1) { p=PHH; }
        else                      { p=PLL; }
      }
      cifra(s[i],p);
      i++;
    }    
    
    if (_rck==255) {
      //if RCK=SI, we use _si to load the output registers
      digitalWrite(_si,LOW);
      digitalWrite(_si,HIGH);
    }
    else
    {
      //if RCK available, we use _rck to load output registers
      digitalWrite(_rck,LOW);
      digitalWrite(_rck,HIGH);
    }
    _setting=false;
  }
}


void DisplayBig::scroll(char c)
{
    _punti=0;     //points will go off while scrolling...
                  //of course you may want to do a clear() before doing scrolling
    
    //insert c (and automatically perform hardware scrolling)
    cifra(c);
    //
    if (_rck==255) {
      //if RCK=SI, we use _si to load the output registers
      digitalWrite(_si,LOW);
      digitalWrite(_si,HIGH);
    }
    else
    {
      //if RCK available, we use _rck to load output registers
      digitalWrite(_rck,LOW);
      digitalWrite(_rck,HIGH);
    }
    
    //scrolls also the buffer that memorizes current display string
    //so any subsequent refresh() will work properly
    String s;
    int i=1;
    while (i<_size) 
    {
      s+=_disp[i];
      i++;
    }
    _disp=s+String(c);
}

void DisplayBig::cifra(char cf,uint8_t pt)
{
      char seg=code7(cf);
      
      //ev. point; now managed below
      //seg=seg & pt;
      
      // seg is 7 6 5 4 3 2 1 point
      // cause hardware wiring we must send
      // 5 6 7 4 1 2 3 0=point
      digitalWrite(_sck,LOW); 
      digitalWrite(_si,bitRead(seg,5));
      digitalWrite(_sck,HIGH);

      digitalWrite(_si,bitRead(seg,6));
      digitalWrite(_sck,LOW); digitalWrite(_sck,HIGH);

      digitalWrite(_si,bitRead(seg,7));
      digitalWrite(_sck,LOW); digitalWrite(_sck,HIGH);

      digitalWrite(_si,bitRead(seg,4));
      digitalWrite(_sck,LOW); digitalWrite(_sck,HIGH);

      digitalWrite(_si,bitRead(seg,1));
      digitalWrite(_sck,LOW); digitalWrite(_sck,HIGH);

      digitalWrite(_si,bitRead(seg,2));
      digitalWrite(_sck,LOW); digitalWrite(_sck,HIGH);

      digitalWrite(_si,bitRead(seg,3));
      digitalWrite(_sck,LOW); digitalWrite(_sck,HIGH);

      digitalWrite(_si,pt);
      digitalWrite(_sck,LOW); digitalWrite(_sck,HIGH);
}


uint32_t DisplayBig::getpoints() {
	return _punti;
}

void DisplayBig::setpoints(uint32_t punti,bool dorefresh) //default dorefresh=false
{
  if (punti!=_punti) {
    _punti=punti;
    if (dorefresh) refresh();
  }
}

//turns ON all the points which bits are 1 in "mask"
void DisplayBig::pointON(uint32_t mask,bool dorefresh) //default dorefresh=false
{
  uint32_t punti=_punti;
  punti=punti | mask;     //H  
  if (punti!=_punti) {
    _punti=punti;
    if (dorefresh) refresh();
  }
}

//turns OFF all the points which bits are 1 in "mask"
void DisplayBig::pointOFF(uint32_t mask,bool dorefresh) //default dorefresh=false
{
  uint32_t punti=_punti;
  punti=punti & (~mask); //L
  if (punti!=_punti) {
    _punti=punti;
    if (dorefresh) refresh();
  }
}

void DisplayBig::setsize(uint8_t size) {
  if (size!=_size) {
    _size=size;
    //refresh();
  }
}

String DisplayBig::getdisp() {
  return _disp;
}


